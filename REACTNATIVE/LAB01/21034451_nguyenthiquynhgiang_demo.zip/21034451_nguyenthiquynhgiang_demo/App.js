import React from 'react';
import { Text, StyleSheet, View, Image } from 'react-native';

//21034451_NguyenThiQuynhGiang

const YourApp = () => {
  return (
    <View style = {style.container}>
    <Image source={{uri:'https://picsum.photos/200'}} style={{height: 100, width: 100}} />
       <Text style = {style.boldText}>HelloWorld</Text>
      <Text style = {style.boldText}>HelloWorld</Text>
    </View>
  );
};

const style = StyleSheet.create({
  container: {
    flex: 1, backgroundColor: 'pink',
    justifyContent: 'center',//Can chinh theo chieu doc (tren xuong duoi)
    alignContent: 'center'//Can chinh theo chieu ngang (trai sang phai)
  },
  boldText: {
    fontWeight: 'bold',
  },
});

export default YourApp;