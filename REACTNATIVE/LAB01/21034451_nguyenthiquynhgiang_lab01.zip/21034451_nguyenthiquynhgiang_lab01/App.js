import * as React from 'react';
import FirstScreen from './components/FirstScreen';
import Screen_1a from './components/Screen_1a';
import Screen_1b from './components/Screen_1b';
import Screen_1c from  './components/Screen_1c';
import Screen_1d from  './components/Screen_1d';


export default function App() {
  return (
    //<FirstScreen /> 
    //<Screen_1a />
    //<Screen_1b />
    //<Screen_1c />
    <Screen_1d />
  );
}
