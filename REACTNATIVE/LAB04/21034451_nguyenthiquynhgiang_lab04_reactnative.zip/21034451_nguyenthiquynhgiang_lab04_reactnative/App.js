import * as React from 'react';
import Footer from './components/Footer';
import Screen_4a from './components/Screen_4a';
import Screen_4b from './components/Screen_4b';

export default function App() {
  return (
    //<Footer />
    //<Screen_4a />
    <Screen_4b />
  );
}
