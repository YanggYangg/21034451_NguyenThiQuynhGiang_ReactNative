import { Text, SafeAreaView, StyleSheet } from 'react-native';
import Screen01 from './components/Screen01'
export default function App() {
  return (
    <Screen01 />
  );
};