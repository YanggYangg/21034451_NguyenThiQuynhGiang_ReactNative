import * as React from 'react';
import Tiki from './components/Tiki';
import PasswordGenerator from './components/PasswordGenerator';

export default function App() {
  return (
    <Tiki />
    //<PasswordGenerator />
    
  );
}

